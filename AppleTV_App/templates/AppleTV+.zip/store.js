function thestore(){
    window.location.href ="apple_store.xhtml"
}
function store(){
    window.location.href ="store.xhtml"
}
function mac(){
    window.location.href ="mac.xhtml"
}
function iPad(){
    window.location.href ="iPad.xhtml"
}
function iPhone(){
    window.location.href ="iPhone.xhtml"
}
function Watch(){
    window.location.href ="Watch.xhtml"
}
function AirPods(){
    window.location.href ="AirPods.xhtml"
}
function AppleTV(){
    window.location.href ="AppleTV.xhtml"
}
function Accesories(){
    window.location.href ="accesories.xhtml"
}
function Support(){
    window.location.href ="https://support.apple.com/en-in"
}
function buy(product_name){
    product = document.getElementsByClassName(product_name);
    window.location.href = "buy_page.xhtml";
    divtag = document.getElementsByClassName(buyimg);
    divtag.src = product[0];
    document.getElementById("buyname").innerHTML = "Hi";
    document.write(product[1]);

}